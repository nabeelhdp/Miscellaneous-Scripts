#!/usr/bin/env python3

import argparse
import contextlib
import json
import sys
import yaml

def main():
    parser = argparse.ArgumentParser(description='convert to and from yaml representation of rules')
    parser.add_argument('files', nargs='*')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--json', action='store_true')
    group.add_argument('--yaml', action='store_true')
    parser.add_argument('--filter')
    parser.add_argument('--re-id', action='store_true')
    args = parser.parse_args()

    read_stdin = '-' in args.files

    with contextlib.ExitStack() as stack:
        file_pts = [ stack.enter_context(open(path, 'r'))
                        for path in args.files
                        if path != '-' ]

        if args.json:
            rule_lists = [json.load(f)['ruleList'] for f in file_pts]
        elif args.yaml:
            rule_lists = [yaml.safe_load(f) for f in file_pts]

    final_rule_list = []
    for rule_list in rule_lists:
        if rule_list:
            final_rule_list = final_rule_list + rule_list

    final_rule_list = sorted(final_rule_list, key=lambda r: r['id'])

    if args.re_id:
        for i, rule in enumerate(final_rule_list):
            rule['id'] = i+1

    if args.filter:
        name, value = args.filter.split('=')

        if value:
            final_rule_list = [ rule
                                for rule in final_rule_list
                                if name in rule and rule[name] == value ]
        else:
            final_rule_list = [ rule
                                for rule in final_rule_list
                                if name not in rule or not rule[name] ]

    if args.json:
        yaml.dump(final_rule_list, sys.stdout)
    elif args.yaml:
        json.dump({'ruleList': final_rule_list}, sys.stdout)


if __name__ == '__main__':
    main()
