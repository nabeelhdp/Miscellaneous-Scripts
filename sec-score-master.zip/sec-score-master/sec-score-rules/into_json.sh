#!/usr/bin/env bash

python convert.py --yaml yaml_out/*/*.yaml | jq | tee ../rulesets/cdp-default-rules.json
