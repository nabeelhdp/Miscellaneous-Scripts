# Scoring guidelines
## Kerberos
* After analyzing the latest ruleset, most of the items have a Kerberos score of 50, so rules that check on Kerberos enablement should score 50
* If a service has a dedicated UI the score should be 10
* Strong encryption types used for Kerberos is a seperate check for weak encryption types so score this 25
## TLS Enablement
* Almost all services have a score of 2 for TLS Enablement, so we can keep this
* Modern Cipher Suite scores 1
## Ranger / Sentry usage
* Scoring ranges between 1 and 10 in the analyzed ruleset, we should score this 5 points
