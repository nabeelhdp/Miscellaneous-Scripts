#!/usr/bn/env bash

mkdir -p yaml

while read -r service
do
  python convert.py \
    --json \
    --filter "service=$service" \
    default-rules.json \
    | tee yaml/$(echo $service.yaml \
            | tr '[:upper:]' '[:lower:]' \
            | tr ' ' '_')
done < <(python convert.py \
         --json default-rules.json  \
         | grep service: \
         | tr -s ' ' \
         | cut -d' ' -f3- \
         | sort | uniq)

python convert.py \
  --json \
  --filter service= \
  default-rules.json \
  | tee yaml/misc.yaml
