#!/usr/bin/env python

import collections
import sys
import os
import yaml

def check_rule(path, rule, final_rule_pairs):
    print(path)
    print(rule)
    choice = None
    while not choice or choice not in 'acmrp':
        choice = input('a(pprove) c(heck) m(odify) r(emove) p(revious): ')

    if choice == 'p':
        if len(final_rule_pairs) > 0:
            prev_path, prev_rule, _ = final_rule_pairs.pop()
            check_rule(prev_path, prev_rule, final_rule_pairs)

        check_rule(path, rule, final_rule_pairs)

    else:
        final_rule_pairs.append((path, rule, choice))


def main():
    _, folder_in, folder_out = sys.argv

    final_rule_pairs = []

    for p in [p for p in os.listdir(folder_in) if p.endswith('.yaml')]:
        with open(os.path.join(folder_in, p), 'r') as f:
            rules = yaml.safe_load(f)

        for r in rules:
            check_rule(p, r, final_rule_pairs)

    grouped_pairs = collections.defaultdict(list)

    for path, rule, choice in final_rule_pairs:
        grouped_pairs[(path, choice)].append(rule)

    for (path, choice), rules in grouped_pairs.items():
        new_path = os.path.join(folder_out, choice, path)

        with open(new_path, 'w') as new_f:
            yaml.dump(rules, new_f)


if __name__ == '__main__':
    main()
