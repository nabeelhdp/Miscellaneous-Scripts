
from pyspark.sql import SparkSession
import pandas as pd
import json
import seaborn as sns
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import plotly.graph_objs as go
import plotly.plotly as py


spark = SparkSession \
    .builder \
    .appName("Security Scanner Analysis") \
    .getOrCreate()
    

# Acquire data from EDH
# -----------------------
#

sns.set(font="DejaVu Sans")

# Explore the dataframe in grid output
pd.options.display.html.table_schema = True
pd.options.display.max_rows = 30

# Load default rules file
file='default-rules.json'
with open(file) as rules_file:
  dict_rules = json.load(rules_file)
  
rulesDf = pd.DataFrame(dict_rules['ruleList']).set_index('id')
rulesDf.rename(columns={'description': 'Description'}, inplace=True)

# Load aggregated results using SparkSQL

resultsPd1 = spark.sql("""SELECT results.ruleid, 
results.pass AS passbool, 
AVG(summary.passrate) as Mean, 
stddev(summary.passrate) as StandardDeviation, 
min(summary.passrate) as Lowest, 
max(summary.passrate) as Highest, 
(COUNT(*) / SUM(COUNT(*))  OVER (PARTITION BY results.ruleid))*100 as PassOrFailRatePercentage, 
(SUM(COUNT(*))  OVER (PARTITION BY results.ruleid) / totalclusters) * 100 as RunRate,
stddev(summary.passrate) / AVG(summary.passrate) as CoefficientOfMean
FROM p_securityscanner.secscoresummary summary 
INNER JOIN p_securityscanner.secscoreresults results ON summary.clusterid = results.clusterid
AND summary.clustername = results.clustername
CROSS JOIN (SELECT COUNT(*) as totalclusters FROM p_securityscanner.secscoresummary) tc
GROUP BY results.ruleid, results.pass, totalclusters""").toPandas().round({'PassOrFailRatePercentage': 1, 'RunRate' : 1})



# Merge resuls together
resultsPd = pd.merge(resultsPd1, rulesDf, left_on='ruleid', right_on='id',how='outer', right_index=True)

# Add Labels
resultsPd['Label'] = resultsPd['ruleid'].map(str) + ': ' + resultsPd['Description']

# Subset into passes and failures
resultsPass = resultsPd.query("passbool == True").sort_values(by=['Mean'], ascending=False)
resultsFail = resultsPd.query("passbool == False").sort_values(by=['Mean'], ascending=False)



# Rules with highest pass rate
# -----------------------
#
resultsPass.query("passbool == True").loc[:, ['ruleid','PassOrFailRatePercentage','RunRate', 'Description']].sort_values(by='PassOrFailRatePercentage', ascending=False)

# Rules with highest failure rate
# -----------------------
#

resultsPd.query("passbool == False").loc[:, ['ruleid','PassOrFailRatePercentage','RunRate', 'Description']].sort_values(by='PassOrFailRatePercentage', ascending=False)

# Rules with highest prediction of score rate
# -------------------------------------------
#
resultsPass.query("passbool == True").loc[:, ['ruleid','Mean','StandardDeviation','RunRate', 'Description']].sort_values(by='StandardDeviation', ascending=True).round({'Mean': 1, 'StandardDeviation':1})
resultsPd.query("passbool == False").loc[:, ['ruleid','Mean','StandardDeviation','RunRate', 'Description']].sort_values(by='StandardDeviation', ascending=True).round({'Mean': 1, 'StandardDeviation':1})

# Note that we have some rules with a very low run rate. Let's remove those with a run rate of less than 20%
resultsPass.query("passbool == True & RunRate >= 20").loc[:, ['ruleid','Mean','StandardDeviation','RunRate', 'Description']].sort_values(by='StandardDeviation', ascending=True).round({'Mean': 1, 'StandardDeviation':1})
resultsPd.query("passbool == False & RunRate >= 20").loc[:, ['ruleid','Mean','StandardDeviation','RunRate', 'Description']].sort_values(by='StandardDeviation', ascending=True).round({'Mean': 1, 'StandardDeviation':1})

# Plot using Seaborn
sns.jointplot(x="Mean", y="StandardDeviation", data=resultsPass.query("passbool == True & RunRate >= 20"));
sns.jointplot(x="Mean", y="StandardDeviation", data=resultsPd.query("passbool == False & RunRate >= 20"));


passes  = resultsPass.query("passbool == True & RunRate >= 20")
passmatrix = passes.as_matrix(['Mean','StandardDeviation'])

X = passmatrix[:,0:1]
Y = passmatrix[:,1]

from sklearn.linear_model import LinearRegression

lin_reg = LinearRegression()
lin_reg.fit(X,Y)



from sklearn.preprocessing import PolynomialFeatures

poly_reg = PolynomialFeatures(degree=3)
X_poly = poly_reg.fit_transform(X)
poly_reg.fit(X_poly, Y)
lin_reg2 = LinearRegression()
lin_reg2.fit(X_poly, Y)

import numpy as np
X_grid = np.arange(min(X), max(X), 0.1)
X_grid = X_grid.reshape(len(X_grid), 1)


fails  = resultsPd.query("passbool == False & RunRate >= 20")
failsmatrix = fails.as_matrix(['Mean','StandardDeviation'])

FX = failsmatrix[:,0:1]
FY = failsmatrix[:,1]


flin_reg = LinearRegression()
flin_reg.fit(FX,FY)


fpoly_reg = PolynomialFeatures(degree=4)  
FX_poly = fpoly_reg.fit_transform(FX)
fpoly_reg.fit(FX_poly, FY)
flin_reg2 = LinearRegression()
flin_reg2.fit(FX_poly, FY)

FX_grid = np.arange(min(FX), max(FX), 0.1)
FX_grid = FX_grid.reshape(len(FX_grid), 1)


init_notebook_mode(connected=True)

# Add further lables for display
resultsPass['LabelWithRunRate'] = resultsPass['ruleid'].map(str) + ': ' + resultsPass['Description'] + ' (' + resultsPass['RunRate'].map(str) + '%)'
resultsFail['LabelWithRunRate'] = resultsFail['ruleid'].map(str) + ': ' + resultsFail['Description'] + ' (' + resultsFail['RunRate'].map(str) + '%)'

# Plot Passes and Failures as Predictions of Overall Score
# --------------------------------------------------------
#

# Create Plotly data

fig = {
    'data': [
        {'x': resultsPass.Mean, 
         'y': resultsPass.StandardDeviation, 
         'text': resultsPass.LabelWithRunRate, 
         'mode': 'markers', 
         'name': 'Pass',
         'marker': {'color': resultsPass.RunRate,
                    'colorscale': [[0, 'rgb(255,255,255)'], [1, 'rgb(0,100,0)']],
                    'showscale': False,
                    },
        },
        {'x': resultsFail.Mean, 
         'y': resultsFail.StandardDeviation, 
         'text': resultsFail.LabelWithRunRate, 
         'mode': 'markers', 
         'name': 'Fail',
         'marker': {'color': resultsFail.RunRate,
                    'colorscale': [[0, 'rgb(255,255,255)'], [1, 'rgb(255,0,0)']],
                    'showscale': False,
                    },
        },
        
      
    ],
    'layout': {
        'title': 'Rule Pass/Fail Predictions for Overall Score',
        'xaxis': {'title': 'Mean'},
        'yaxis': {'title': "Standard Deviation"},
        'hovermode' : 'closest',
        'width' : 700,          
        'height' : 700
    }
}

#Passes Only
fig = {
    'data': [
        {'x': resultsPass.Mean, 
         'y': resultsPass.StandardDeviation, 
         'text': resultsPass.LabelWithRunRate, 
         'mode': 'markers', 
         'name': 'Pass',
         'marker': {'color': resultsPass.RunRate,
                    'colorscale': [[0, 'rgb(255,255,255)'], [1, 'rgb(0,100,0)']],
                    'showscale': False,
                    },
        },
        {'x': X_grid, 
         'y': lin_reg2.predict(poly_reg.fit_transform(X_grid)), 
         'mode': 'lines', 
         'name': 'trend',
        },
        
    ],
    'layout': {
        'title': 'Rule Pass/Fail Predictions for Overall Score',
        'xaxis': {'title': 'Mean'},
        'yaxis': {'title': "Standard Deviation"},
        'hovermode' : 'closest',
        'width' : 700,          
        'height' : 700
    }
}

#Failures Only
fig = {
    'data': [
        {'x': resultsFail.Mean, 
         'y': resultsFail.StandardDeviation, 
         'text': resultsFail.LabelWithRunRate, 
         'mode': 'markers', 
         'name': 'Fail',
         'marker': {'color': resultsFail.RunRate,
                    'colorscale': [[0, 'rgb(255,255,255)'], [1, 'rgb(255,0,0)']],
                    'showscale': False,
                    },
        },
        {'x': FX_grid, 
         'y': flin_reg2.predict(fpoly_reg.fit_transform(FX_grid)), 
         'mode': 'lines', 
         'name': 'trend',
        }
      
    ],
    'layout': {
        'title': 'Rule Pass/Fail Predictions for Overall Score',
        'xaxis': {'title': 'Mean'},
        'yaxis': {'title': "Standard Deviation"},
        'hovermode' : 'closest',
        'width' : 700,          
        'height' : 700
    }
}

fig = {
    'data': [
        {'x': resultsPass.Mean, 
         'y': resultsPass.StandardDeviation, 
         'text': resultsPass.LabelWithRunRate, 
         'mode': 'markers', 
         'name': 'Pass',
         'marker': {'color': resultsPass.RunRate,
                    'colorscale': [[0, 'rgb(255,255,255)'], [1, 'rgb(0,100,0)']],
                    'showscale': False,
                    },
        },
        {'x': resultsFail.Mean, 
         'y': resultsFail.StandardDeviation, 
         'text': resultsFail.LabelWithRunRate, 
         'mode': 'markers', 
         'name': 'Fail',
         'marker': {'color': resultsFail.RunRate,
                    'colorscale': [[0, 'rgb(255,255,255)'], [1, 'rgb(255,0,0)']],
                    'showscale': False,
                    },
        },
        {'x': X_grid, 
         'y': lin_reg2.predict(poly_reg.fit_transform(X_grid)), 
         'mode': 'lines', 
         'name': 'trend',
        },
        {'x': FX_grid, 
         'y': flin_reg2.predict(fpoly_reg.fit_transform(FX_grid)), 
         'mode': 'lines', 
         'name': 'trend',
        }
      
    ],
    'layout': {
        'title': 'Rule Pass/Fail Predictions for Overall Score',
        'xaxis': {'title': 'Mean'},
        'yaxis': {'title': "Standard Deviation"},
        'hovermode' : 'closest',
        'width' : 700,          
        'height' : 700
    }
}


py.iplot(fig, filename='Rule overall indicator summary')

# Plot Pass-rates for each individual rule
# ------------------------------------------
#

resultsPass['LabelWithPassRate'] = resultsPass['ruleid'].map(str) + ': ' + resultsPass['Description'] + ' (' + resultsPass['PassOrFailRatePercentage'].map(str) + '%)'

data = [go.Bar(
            x=resultsPass.ruleid,
            y=resultsPass.PassOrFailRatePercentage,
            text=resultsPass.LabelWithPassRate
    )]

layout = go.Layout(
    title='Rules Passrate',
    width=700,
    height=300,
    hovermode='closest',
    xaxis={'title':'Rule ID'},
    yaxis={'title':'Pass Rate %age'}
)

fig = go.Figure(data=data, layout=layout)

py.iplot(fig, filename='Rules passrate')


# Apriori Testing
from apyori import apriori

resultspd2 = spark.sql("""SELECT CONCAT(clusterid, clustername) AS cluster, CONCAT(ruleid, pass) ruleResult FROM p_securityscanner.secscoreresults""").toPandas();

resultspd2 = spark.sql("""SELECT DISTINCT CONCAT(r.clusterid, r.clustername) AS cluster, CONCAT(r.ruleid, r.pass) ruleResult
FROM p_securityscanner.secscoreresults r INNER JOIN
p_securityscanner.secscoreresults p
ON p.clusterid = r.clusterid AND p.clustername = r.clustername
INNER JOIN (
SELECT ruleid, passbool FROM (
SELECT results.ruleid, 
results.pass AS passbool, 
(COUNT(*) / SUM(COUNT(*))  OVER (PARTITION BY results.ruleid))*100 as PassOrFailRatePercentage, 
(SUM(COUNT(*))  OVER (PARTITION BY results.ruleid) / totalclusters) * 100 as RunRate
FROM p_securityscanner.secscoreresults results 
CROSS JOIN (SELECT COUNT(*) as totalclusters FROM p_securityscanner.secscoresummary) tc
GROUP BY results.ruleid, results.pass, totalclusters
) as foo WHERE PassOrFailRatePercentage < 10 AND passbool = true) as PASSRATES
ON r.ruleid = PASSRATES.ruleid AND r.pass = passrates.passbool
ORDER BY cluster""").toPandas();

resultspd21 = resultspd2.groupby('cluster')['ruleResult'].apply(list)

resultslist = resultspd21.tolist()

rules = apriori(resultslist, min_support = 0.003, min_confidence = 0.2, min_lift = 3, min_length = 2)

#results = list(rules)

#results
from pyspark.ml.fpm import FPGrowth

df = spark.createDataFrame([
    (0, [1, 2, 5]),
    (1, [1, 2, 3, 5]),
    (2, [1, 2])
], ["id", "items"])

fpGrowth = FPGrowth(itemsCol="items", minSupport=0.5, minConfidence=0.6)
model = fpGrowth.fit(df)

# Display frequent itemsets.
model.freqItemsets.show()

# Display generated association rules.
model.associationRules.show()

# transform examines the input items against all the association rules and summarize the
# consequents as prediction
model.transform(df).show()

from pyspark.ml.fpm import FPGrowth
from pyspark.sql import functions as F

#df2 = spark.sql("""SELECT DISTINCT CONCAT(clusterid, clustername) AS cluster, CONCAT(ruleid, pass) ruleResult FROM p_securityscanner.secscoreresults""")

df2 = spark.sql("""SELECT DISTINCT CONCAT(r.clusterid, r.clustername) AS cluster, /*CONCAT(*/r.ruleid/*, r.pass)*/ ruleResult
FROM p_securityscanner.secscoreresults r INNER JOIN
p_securityscanner.secscoreresults p
ON p.clusterid = r.clusterid AND p.clustername = r.clustername
INNER JOIN (
SELECT ruleid, passbool FROM (
SELECT results.ruleid, 
results.pass AS passbool, 
(COUNT(*) / SUM(COUNT(*))  OVER (PARTITION BY results.ruleid))*100 as PassOrFailRatePercentage, 
(SUM(COUNT(*))  OVER (PARTITION BY results.ruleid) / totalclusters) * 100 as RunRate
FROM p_securityscanner.secscoreresults results 
CROSS JOIN (SELECT COUNT(*) as totalclusters FROM p_securityscanner.secscoresummary) tc
GROUP BY results.ruleid, results.pass, totalclusters
) as foo WHERE PassOrFailRatePercentage < 20 AND passbool = true AND ruleid NOT IN(48,49,50,51,52,53)) as PASSRATES
ON r.ruleid = PASSRATES.ruleid AND r.pass = passrates.passbool
ORDER BY cluster""")

df2 = df2.groupBy('cluster').agg(F.collect_list("ruleResult")).repartition(100)

fpGrowth = FPGrowth(itemsCol="collect_list(ruleResult)", minSupport=0.02, minConfidence=0.9, numPartitions=20)
model = fpGrowth.fit(df2)

# Display frequent itemsets.
freqItemsets = model.freqItemsets

freqItemsets.show()

# Display generated association rules.
assocRules = model.associationRules

join = assocRules.join(freqItemsets, assocRules.consequent==freqItemsets.items)
#joint2 = join.rdd.map(lambda rule : (rule.antecedent, consequent, confidence, confidence * (df.count() / freq))  )
joinDf = join.toPandas()

cntr = df2.count();

del joinDf['items']
joinDf['lift'] = joinDf['confidence'] * (cntr / joinDf['freq'])
#joinDf = joinDf.drop(columns=['items', 'freq'])

del joinDf['freq']

pd.options.display.max_rows = 100
joinDf.sort_values('lift', ascending=False)



from pyspark.ml.fpm import FPGrowth

df = spark.createDataFrame([
    (0, ["milk", "bread"]),
    (1, ["butter"]),
    (2, ["beer", "diapers"]),
    (3, ["milk", "bread", "butter"] ),
    (4, ["bread"],)
], ["id", "items"])

fpGrowth = FPGrowth(itemsCol="items", minSupport=0.2, minConfidence=0.2)
model = fpGrowth.fit(df)

# Display frequent itemsets.
freqItemsets = model.freqItemsets

freqItemsets.show()

# Display generated association rules.
assocRules = model.associationRules

join = assocRules.join(freqItemsets, assocRules.consequent==freqItemsets.items)
#joint2 = join.rdd.map(lambda rule : (rule.antecedent, consequent, confidence, confidence * (df.count() / freq))  )
joinDf = join.toPandas()

joinDf['lift'] = joinDf['confidence'] * (df.count() / joinDf['freq'])
#joinDf = joinDf.drop(columns=['items', 'freq'])
del joinDf['items']
del joinDf['freq']

pd.options.display.max_rows = 100
joinDf.sort_values('lift', ascending=False)

df.count();
# transform examines the input items against all the association rules and summarize the
# consequents as prediction
model.transform(df).show()
