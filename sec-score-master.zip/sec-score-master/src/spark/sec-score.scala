import org.apache.spark.sql.Row
import scala.collection.JavaConverters._
import org.apache.spark.sql.types.
         {StructType, StructField, StringType, FloatType}


spark.sql("set hive.exec.dynamic.partition=true")
spark.sql("set hive.exec.dynamic.partition.mode=nonstrict")

%ShowTypes on

val inputRun = 20180716234805l
val outputRun = 20180731071650l

//Read List of clusters from Hive external table
val clustersDf = spark.sql("SELECT * FROM p_securityscanner.clustercollectionsall WHERE runid = " + inputRun)
  
def readHdfsFile(path: String) : Option[String] =
  try {
      val hdfs = org.apache.hadoop.fs.FileSystem.get(new org.apache.hadoop.conf.Configuration())
      val t=hdfs.listStatus(new org.apache.hadoop.fs.Path(path))
      val in = hdfs.open(t(0).getPath)
      val reader = new java.io.BufferedReader(new java.io.InputStreamReader(in))
      Some(Iterator.continually(reader.readLine()).takeWhile(_ != null).mkString)  
} catch { 
    case e:Exception=>
      None
} 


val clustersRdd = clustersDf.map(x => (x.getAs[String]("clusterid"),
                                       x.getAs[String]("path"),
                                       x.getAs[String]("clustername")
                                      )
                                ).rdd.repartition(32)

val filesRdd = clustersRdd.map(x => (x._1, readHdfsFile(x._2), x._3)).filter(x=> x._2 != None)

val ResultsRdd = filesRdd.map(x => (x._1, com.cloudera.fce.security.secscore.SecScore.simpleGetResults(x._2.get, x._1)
                                   )).filter(x=>x._2 != null)

val flatMapped = ResultsRdd.flatMapValues(e => e.asScala).cache

case class ResultSummary(ClusterId: String, ClusterName: String, fullVersion: String, PassRate: Float, FailedScope: Int, RunId: Long);

val summaryDf = flatMapped.map(x=> ResultSummary(x._1, x._2.getClusterName, x._2.getFullVersion, x._2.getPassRateFloat, x._2.getMaximumScore - x._2.getTotalScore, outputRun)).toDF()

val ruleResults=flatMapped.map(x=>((x._1,x._2.getClusterName),x._2.getResultList)).flatMapValues(e=>e.asScala).cache


case class RuleResults(ClusterId: String, ClusterName: String, RuleId: Int, Pass: Boolean, Service: String, Level: Int, Score: Int, Description: String, RunId: Long)

val rulesDf = ruleResults.map(x=>RuleResults(x._1._1, x._1._2, x._2.getId, x._2.isPass, x._2.getService, x._2.getLevel, x._2.getScore, x._2.getDescription, outputRun)).toDF()  
  

val count = clustersRdd.count
count

rulesDf.write.mode("append").insertInto("p_securityscanner.secscoreresults");
summaryDf.write.mode("append").insertInto("p_securityscanner.secscoresummary");


val summaryResults = spark.sql("""SELECT summary.runid, results.pass kerberized, MIN(summary.passrate) minscore, avg(summary.passrate) avgscore, 
 percentile_approx(summary.passrate, 0.5), MAX(summary.passrate) maxscore
FROM clusterstats.cluster_metadata c 
INNER JOIN default.unification u ON c.clusterid = u.clusterstat
INNER JOIN sfdc.cluster__c s ON u.salesforce = s.id
INNER JOIN sfdc.account a ON a.id = s.account_name__c 
INNER JOIN p_securityscanner.secscoresummary summary ON summary.clusterid = c.clusterid
INNER JOIN p_securityscanner.secscoreresults results ON summary.clusterid = results.clusterid 
AND summary.clustername = results.clustername
WHERE results.ruleid = 1
AND results.runid = summary.runid
AND c.cdhversion >= '5' AND c.cdhversion != 'NO_SCRIPT'
GROUP BY results.pass, summary.runid""")

summaryResults.show


