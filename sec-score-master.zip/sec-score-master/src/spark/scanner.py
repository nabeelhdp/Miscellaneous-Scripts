
from pyspark.sql import SparkSession
import pandas as pd
import json
import seaborn as sns
from plotly import __version__
from plotly.offline import download_plotlyjs, init_notebook_mode, plot, iplot
import plotly.graph_objs as go
import plotly.plotly as py


# Acquire data from EDH
# -----------------------
#

sns.set(font="DejaVu Sans")

# Explore the dataframe in grid output
pd.options.display.html.table_schema = True
pd.options.display.max_rows = 20

# Load default rules file
file='default-rules.json'
with open(file) as rules_file:
  dict_rules = json.load(rules_file)
  
rulesDf = pd.DataFrame(dict_rules['ruleList']).set_index('id')
rulesDf.rename(columns={'description': 'Description'}, inplace=True)

# Load aggregated results using SparkSQL
spark = SparkSession \
    .builder \
    .appName("Security Scanner Analysis") \
    .getOrCreate()
    
resultsPd1 = spark.sql("""SELECT results.ruleid, 
results.pass AS passbool, 
AVG(summary.passrate) as Mean, 
stddev(summary.passrate) as StandardDeviation, 
min(summary.passrate) as Lowest, 
max(summary.passrate) as Highest, 
(COUNT(*) / SUM(COUNT(*))  OVER (PARTITION BY results.ruleid))*100 as PassOrFailRatePercentage, 
(SUM(COUNT(*))  OVER (PARTITION BY results.ruleid) / totalclusters) * 100 as RunRate,
stddev(summary.passrate) / AVG(summary.passrate) as CoefficientOfMean
FROM p_securityscanner.secscoresummary summary 
INNER JOIN p_securityscanner.secscoreresults results ON summary.clusterid = results.clusterid
AND summary.clustername = results.clustername
CROSS JOIN (SELECT COUNT(*) as totalclusters FROM p_securityscanner.secscoresummary) tc
GROUP BY results.ruleid, results.pass, totalclusters""").toPandas().round({'PassOrFailRatePercentage': 1, 'RunRate' : 1})



# Merge resuls together
resultsPd = pd.merge(resultsPd1, rulesDf, left_on='ruleid', right_on='id',how='outer', right_index=True)

# Add Labels
resultsPd['Label'] = resultsPd['ruleid'].map(str) + ': ' + resultsPd['Description']

# Subset into passes and failures
resultsPass = resultsPd.query("passbool == True").sort_values(by=['Mean'], ascending=False)
resultsFail = resultsPd.query("passbool == False").sort_values(by=['Mean'], ascending=False)



# Rules with highest pass rate
# -----------------------
#
resultsPass.query("passbool == True").loc[:, ['ruleid','PassOrFailRatePercentage','RunRate', 'Description']].sort_values(by='PassOrFailRatePercentage', ascending=False)

# Rules with highest failure rate
# -----------------------
#

resultsPd.query("passbool == False").loc[:, ['ruleid','PassOrFailRatePercentage','RunRate', 'Description']].sort_values(by='PassOrFailRatePercentage', ascending=False)

# Rules with highest prediction of score rate
# -------------------------------------------
#
resultsPass.query("passbool == True").loc[:, ['ruleid','Mean','StandardDeviation','RunRate', 'Description']].sort_values(by='StandardDeviation', ascending=True).round({'Mean': 1, 'StandardDeviation':1})
resultsPd.query("passbool == False").loc[:, ['ruleid','Mean','StandardDeviation','RunRate', 'Description']].sort_values(by='StandardDeviation', ascending=True).round({'Mean': 1, 'StandardDeviation':1})

# Note that we have some rules with a very low run rate. Let's remove those with a run rate of less than 20%
resultsPass.query("passbool == True & RunRate >= 20").loc[:, ['ruleid','Mean','StandardDeviation','RunRate', 'Description']].sort_values(by='StandardDeviation', ascending=True).round({'Mean': 1, 'StandardDeviation':1})
resultsPd.query("passbool == False & RunRate >= 20").loc[:, ['ruleid','Mean','StandardDeviation','RunRate', 'Description']].sort_values(by='StandardDeviation', ascending=True).round({'Mean': 1, 'StandardDeviation':1})

# Plot using Seaborn
sns.jointplot(x="Mean", y="StandardDeviation", data=resultsPass.query("passbool == True & RunRate >= 20"));
sns.jointplot(x="Mean", y="StandardDeviation", data=resultsPd.query("passbool == False & RunRate >= 20"));


init_notebook_mode(connected=True)

# Add further lables for display
resultsPass['LabelWithRunRate'] = resultsPass['ruleid'].map(str) + ': ' + resultsPass['Description'] + ' (' + resultsPass['RunRate'].map(str) + '%)'
resultsFail['LabelWithRunRate'] = resultsFail['ruleid'].map(str) + ': ' + resultsFail['Description'] + ' (' + resultsFail['RunRate'].map(str) + '%)'

# Plot Passes and Failures as Predictions of Overall Score
# --------------------------------------------------------
#

# Create Plotly data
fig = {
    'data': [
        {'x': resultsPass.Mean, 
         'y': resultsPass.StandardDeviation, 
         'text': resultsPass.LabelWithRunRate, 
         'mode': 'markers', 
         'name': 'Pass',
         'marker': {'color': resultsPass.RunRate,
                    'colorscale': [[0, 'rgb(255,255,255)'], [1, 'rgb(0,100,0)']],
                    'showscale': False,
                    },
        },
        {'x': resultsFail.Mean, 
         'y': resultsFail.StandardDeviation, 
         'text': resultsFail.LabelWithRunRate, 
         'mode': 'markers', 
         'name': 'Fail',
         'marker': {'color': resultsFail.RunRate,
                    'colorscale': [[0, 'rgb(255,255,255)'], [1, 'rgb(255,0,0)']],
                    'showscale': False,
                    },}
    ],
    'layout': {
        'title': 'Rule Pass/Fail Predictions for Overall Score',
        'xaxis': {'title': 'Mean'},
        'yaxis': {'title': "Standard Deviation"},
        'hovermode' : 'closest',
        'width' : 700,          
        'height' : 700
    }
}

py.iplot(fig, filename='Rule overall indicator summary')

# Plot Pass-rates for each individual rule
# ------------------------------------------
#

resultsPass['LabelWithPassRate'] = resultsPass['ruleid'].map(str) + ': ' + resultsPass['Description'] + ' (' + resultsPass['PassOrFailRatePercentage'].map(str) + '%)'

data = [go.Bar(
            x=resultsPass.ruleid,
            y=resultsPass.PassOrFailRatePercentage,
            text=resultsPass.LabelWithPassRate
    )]

layout = go.Layout(
    title='Rules Passrate',
    width=700,
    height=300,
    hovermode='closest',
    xaxis={'title':'Rule ID'},
    yaxis={'title':'Pass Rate %age'}
)

fig = go.Figure(data=data, layout=layout)

py.iplot(fig, filename='Rules passrate')

