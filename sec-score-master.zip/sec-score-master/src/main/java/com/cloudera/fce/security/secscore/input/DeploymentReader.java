package com.cloudera.fce.security.secscore.input;

import java.io.IOException;
import java.util.Collection;

public interface DeploymentReader {
    Collection<DeploymentInfo> readAll() throws IOException;
}
