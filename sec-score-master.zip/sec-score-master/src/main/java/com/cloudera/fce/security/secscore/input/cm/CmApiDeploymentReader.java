package com.cloudera.fce.security.secscore.input.cm;

import com.cloudera.api.ClouderaManagerClientBuilder;
import com.cloudera.api.DataView;
import com.cloudera.api.model.ApiDeployment;
import com.cloudera.api.v8.ClouderaManagerResourceV8;
import com.cloudera.fce.security.secscore.input.DeploymentInfo;
import com.cloudera.fce.security.secscore.input.DeploymentReader;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collection;
import java.util.Collections;

public class CmApiDeploymentReader implements DeploymentReader {

    private ClouderaManagerResourceV8 clouderaManager;

    public CmApiDeploymentReader(String url, String username, String password) {
        this(url, username, password, false);
    }

    public CmApiDeploymentReader(String url, String username, String password,
                                 boolean disableTlsValidation) {
        try {
            ClouderaManagerClientBuilder builder = new ClouderaManagerClientBuilder()
                .withBaseURL(new URL(url))
                .withUsernamePassword(username, password);
            if (disableTlsValidation) {
                builder = builder.disableTlsCertValidation();
                builder = builder.disableTlsCnValidation();
            }
            clouderaManager = builder.build().getRootV8().getClouderaManagerResource();
        } catch (MalformedURLException e) {
            throw new IllegalArgumentException(e);
        }
    }

    public Collection<DeploymentInfo> readAll() {
        ApiDeployment deployment = clouderaManager.getDeployment(DataView.EXPORT_REDACTED);
        return Collections.singletonList(new DeploymentInfo(deployment));
    }

}
