package com.cloudera.fce.security.secscore.input.file;

import com.cloudera.fce.security.secscore.input.DeploymentInfo;
import com.cloudera.fce.security.secscore.input.DeploymentReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.*;

public class FileDeploymentReader implements DeploymentReader {

    private File inputFile;

    public FileDeploymentReader(String inputPath) throws IOException {
        this(new File(inputPath));
    }

    public FileDeploymentReader(File inputFile) throws IOException {
        if (!inputFile.exists()) {
            throw new FileNotFoundException(
                "Deployment inputFile '" + inputFile + "' does not exist");
        }
        this.inputFile = inputFile;
    }

    public Collection<DeploymentInfo> readAll() throws IOException {
        List<DeploymentInfo> deployments = new LinkedList<DeploymentInfo>();
        for (File jsonFile : getJsonFilesFrom(this.inputFile)) {
            deployments.add(new DeploymentInfo(jsonFile));
        }
        return deployments;
    }

    private List<File> getJsonFilesFrom(File file) {
        if (file == null) {
            return Collections.emptyList();
        }
        if (file.isFile()) {
            return Collections.singletonList(file);
        }
        File[] jsonFiles = file.listFiles(JsonFilenameFilter.INSTANCE);
        if (jsonFiles == null) {
            return Collections.emptyList();
        }
        return Arrays.asList(jsonFiles);
    }

    private static final class JsonFilenameFilter implements FilenameFilter {

        static final JsonFilenameFilter INSTANCE = new JsonFilenameFilter();

        private JsonFilenameFilter() {}

        public boolean accept(File dir, String name) {
            return name.toLowerCase().endsWith(".json");
        }

    }

}
