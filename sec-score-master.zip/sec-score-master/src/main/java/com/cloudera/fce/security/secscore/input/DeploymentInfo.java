package com.cloudera.fce.security.secscore.input;

import com.cloudera.api.ApiObjectMapper;
import com.cloudera.api.model.ApiDeployment;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;

public class DeploymentInfo {

    private ApiDeployment apiDeployment;
    private ObjectMapper mapper = new ApiObjectMapper();

    public DeploymentInfo(ApiDeployment apiDeployment) {
        this.apiDeployment = apiDeployment;
    }

    public DeploymentInfo(File file) throws IOException {
        mapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
        this.apiDeployment = mapper.readValue(file, ApiDeployment.class);
    }

    public DeploymentInfo(byte[] data) throws IOException {
        this.apiDeployment = mapper.readValue(data, ApiDeployment.class);
    }

    public String toJson() throws IOException {
        StringWriter out = new StringWriter();
        mapper.writeValue(out, apiDeployment);
        return out.toString();
    }

    public String toXml() throws JsonProcessingException {
        XmlMapper xmlMapper = new XmlMapper();
        return xmlMapper.writeValueAsString(apiDeployment);
    }

}
